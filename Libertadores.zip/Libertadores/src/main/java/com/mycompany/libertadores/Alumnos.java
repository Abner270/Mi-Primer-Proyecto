/*interfaz*/
package com.mycompany.libertadores;

import javax.swing.JTextField;
import javax.swing.JOptionPane;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

public class Alumnos {
 int codigo;
 String Nombre;
 String Apellidos;
 String Materia1;
 String Materia2;
 String Materia3;
 String Materia4;
 String Materia5;
 String Materia6;
 String Materia7;
 String Materia8;
 String Materia9;
 String Materia10;
 String Materia11;
 String Materia12;
    
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }
    
    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellidos() {
        return Apellidos;
    }

    public void setApellidos(String Apellidos) {
        this.Apellidos = Apellidos;
    }

    public String getMateria1() {
        return Materia1;
    }

    public void setMateria1(String Materia1) {
        this.Materia1 = Materia1;
    }

    public String getMateria2() {
        return Materia2;
    }

    public void setMateria2(String Materia2) {
        this.Materia2 = Materia2;
    }

    public String getMateria3() {
        return Materia3;
    }

    public void setMateria3(String Materia3) {
        this.Materia3 = Materia3;
    }

    public String getMateria4() {
        return Materia4;
    }

    public void setMateria4(String Materia4) {
        this.Materia4 = Materia4;
    }

    public String getMateria5() {
        return Materia5;
    }

    public void setMateria5(String Materia5) {
        this.Materia5 = Materia5;
    }

    public String getMateria6() {
        return Materia6;
    }

    public void setMateria6(String Materia6) {
        this.Materia6 = Materia6;
    }

    public String getMateria7() {
        return Materia7;
    }

    public void setMateria7(String Materia7) {
        this.Materia7 = Materia7;
    }

    public String getMateria8() {
        return Materia8;
    }

    public void setMateria8(String Materia8) {
        this.Materia8 = Materia8;
    }

    public String getMateria9() {
        return Materia9;
    }

    public void setMateria9(String Materia9) {
        this.Materia9 = Materia9;
    }

    public String getMateria10() {
        return Materia10;
    }

    public void setMateria10(String Materia10) {
        this.Materia10 = Materia10;
    }
        
    public String getMateria11() {
        return Materia11;
    }

    public void setMateria11(String Materia11) {
        this.Materia11 = Materia11;
    }

    public String getMateria12() {
        return Materia12;
    }

    public void setMateria12(String Materia12) {
        this.Materia12 = Materia12;
    }

 
public void InsertarAlumnos(JTextField paramNombre,JTextField paramApellidos, JTextField paramMateria1, JTextField paramMateria2, JTextField paramMateria3, JTextField paramMateria4, JTextField paramMateria5, JTextField paramMateria6, JTextField paramMateria7, JTextField paramMateria8, JTextField paramMateria9, JTextField paramMateria10, JTextField paramMateria11, JTextField paramMateria12){
    setNombre(paramNombre.getText());
    setApellidos(paramApellidos.getText());
    setMateria1(paramMateria1.getText());
    setMateria2(paramMateria2.getText());
    setMateria3(paramMateria3.getText());
    setMateria4(paramMateria4.getText());
    setMateria5(paramMateria5.getText());
    setMateria6(paramMateria6.getText());
    setMateria7(paramMateria7.getText());
    setMateria8(paramMateria8.getText());
    setMateria9(paramMateria9.getText());
    setMateria10(paramMateria10.getText());
    setMateria11(paramMateria11.getText());
    setMateria12(paramMateria12.getText());
    Conexion objetoConexion = new Conexion();
    String consulta ="INSERT INTO 1A (NOMBRE, APELLIDOS, ESPAÑOL, MATEMATICAS, GEOGRAFIA, CIENCIAS, LENGUA_EXTRANJERA, DEPORTE, ARTES, INFORMATICA, HISTORIA, TUTORIA, VIDA_SALUDABLE, EQUIDAD_DE_GENERO) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?); ";
       
        try{
            CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
            cs.setString(1, getNombre());
            cs.setString(2, getApellidos());
            cs.setString(3, getMateria1());
            cs.setString(4, getMateria2());
            cs.setString(5, getMateria3());
            cs.setString(6, getMateria4());
            cs.setString(7, getMateria5());
            cs.setString(8, getMateria6());
            cs.setString(9, getMateria7());
            cs.setString(10, getMateria8());
            cs.setString(11, getMateria9());
            cs.setString(12, getMateria10());
            cs.setString(13, getMateria11());
            cs.setString(14, getMateria12());
            cs.execute();
            JOptionPane.showMessageDialog(null,"Se inserto correctamente");  
 
            } 
        catch (Exception e){
            JOptionPane.showMessageDialog(null,"No se inserto correctamente"+e.toString());
            }
       

}
public void MostrarAlumnos(JTable paramTablaCalificaciones){
     Conexion objetoConexion = new Conexion();
     DefaultTableModel modelo = new DefaultTableModel();
     TableRowSorter<TableModel> OrdenarTabla = new TableRowSorter<TableModel> (modelo);
     paramTablaCalificaciones.setRowSorter(OrdenarTabla);
     String sql= "";
     modelo.addColumn("Id");
     modelo.addColumn("Nombre");
     modelo.addColumn("Apellidos");
     modelo.addColumn("Español");
     modelo.addColumn("Matematicas");
     modelo.addColumn("Geografia");
     modelo.addColumn("Ciencias");
     modelo.addColumn("Lengua_Extrangera");
     modelo.addColumn("Deporte");
     modelo.addColumn("Artes");
     modelo.addColumn("Informatica");
     modelo.addColumn("Historia");
     modelo.addColumn("Tutoria");
     modelo.addColumn("Vida_Saludable");
     modelo.addColumn("Equidad_De_Genero");
     
     paramTablaCalificaciones.setModel(modelo);
     
     sql = "SELECT * FROM 1A;";
     String[] datos = new String [15];
     Statement st;
     
     try {
         st = objetoConexion.estableceConexion().createStatement();
         ResultSet rs = st.executeQuery(sql);
         while (rs.next()) {             
             datos[0] = rs.getString(1);
             datos[1] = rs.getString(2);
             datos[2] = rs.getString(3);
             datos[3] = rs.getString(4);
             datos[4] = rs.getString(5);
             datos[5] = rs.getString(6);
             datos[6] = rs.getString(7);
             datos[7] = rs.getString(8);
             datos[8] = rs.getString(9);
             datos[9] = rs.getString(10);
             datos[10] = rs.getString(11);
             datos[11] = rs.getString(12);
             datos[12] = rs.getString(13);
             datos[13] = rs.getString(14);  
             datos[14] = rs.getString(15);
             modelo.addRow(datos);
         }
         paramTablaCalificaciones.setModel(modelo);
         
     } catch (Exception e) {
         JOptionPane.showMessageDialog(null, "No se pudo Mostrar los registos, error: " + e.toString());
     }
     
 } 
public void ModificarAlumnos(JTextField paramCodigo, JTextField paramNombre,JTextField paramApellidos, JTextField paramMateria1, JTextField paramMateria2, JTextField paramMateria3, JTextField paramMateria4, JTextField paramMateria5, JTextField paramMateria6, JTextField paramMateria7, JTextField paramMateria8, JTextField paramMateria9, JTextField paramMateria10, JTextField paramMateria11, JTextField paramMateria12){
setCodigo(Integer.parseInt(paramCodigo.getText()));
setNombre(paramNombre.getText());
setApellidos(paramApellidos.getText());
setMateria1(paramMateria1.getText());
setMateria2(paramMateria2.getText());
setMateria3(paramMateria3.getText());
setMateria4(paramMateria4.getText());
setMateria5(paramMateria5.getText());
setMateria6(paramMateria6.getText());
setMateria7(paramMateria7.getText());
setMateria8(paramMateria8.getText());
setMateria9(paramMateria9.getText());
setMateria10(paramMateria10.getText());
setMateria11(paramMateria11.getText());
setMateria12(paramMateria12.getText());
Conexion objetoConexion = new Conexion();

String consulta = "UPDATE 1A SET 1A.NOMBRE = ?, 1A.APELLIDOS = ?, 1A.ESPAÑOL = ?, 1A.MATEMATICAS = ?, 1A.GEOGRAFIA = ?, 1A.CIENCIAS = ?, 1A.LENGUA_EXTRANJERA = ?, 1A.DEPORTE = ?, 1A.ARTES = ?, 1A.INFORMATICA = ?, 1A.HISTORIA = ?, 1A.TUTORIA = ?, 1A.VIDA_SALUDABLE = ?, 1A.EQUIDAD_DE_GENERO = ? WHERE 1A.ID = ?;";
    try {
        CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
        cs.setString(1, getNombre());
        cs.setString(2, getApellidos());
        cs.setString(3, getMateria1());
        cs.setString(4, getMateria2());
        cs.setString(5, getMateria3());
        cs.setString(6, getMateria4());
        cs.setString(7, getMateria5());
        cs.setString(8, getMateria6());
        cs.setString(9, getMateria7());
        cs.setString(10, getMateria8());
        cs.setString(11, getMateria9());
        cs.setString(12, getMateria10());
        cs.setString(13, getMateria11());
        cs.setString(14, getMateria12());
        cs.setInt(15, getCodigo());
        cs.execute();
        JOptionPane.showMessageDialog(null, "Modificacion Exitosa");
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al modificar, error: " + e.toString());
    }
}
public void EliminarAlumnos(JTextField paramCodigo){
    setCodigo(Integer.parseInt(paramCodigo.getText()));
    Conexion objetoConexion = new Conexion();
    String consulta = "DELETE FROM 1A WHERE 1A.ID = ?";
    try{
        CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
        cs.setInt(1, getCodigo());
        cs.execute();
        JOptionPane.showMessageDialog(null, "Se elimino correctamente");
        
    } catch (SQLException e){
        JOptionPane.showMessageDialog(null, "No se pudo eliminar, error: " + e.toString());
    }
}
public void InsertarAlumnos1(JTextField paramNombre,JTextField paramApellidos, JTextField paramMateria1, JTextField paramMateria2, JTextField paramMateria3, JTextField paramMateria4, JTextField paramMateria5, JTextField paramMateria6, JTextField paramMateria7, JTextField paramMateria8, JTextField paramMateria9, JTextField paramMateria10, JTextField paramMateria11, JTextField paramMateria12){
    
        setNombre(paramNombre.getText());
        setApellidos(paramApellidos.getText());
        setMateria1(paramMateria1.getText());
        setMateria2(paramMateria2.getText());
        setMateria3(paramMateria3.getText());
        setMateria4(paramMateria4.getText());
        setMateria5(paramMateria5.getText());
        setMateria6(paramMateria6.getText());
        setMateria7(paramMateria7.getText());
        setMateria8(paramMateria8.getText());
        setMateria9(paramMateria9.getText());
        setMateria10(paramMateria10.getText());
        setMateria11(paramMateria11.getText());
        setMateria12(paramMateria12.getText());    
        Conexion objetoConexion = new Conexion();
        String consulta ="INSERT INTO 1B (NOMBRE, APELLIDOS, ESPAÑOL, MATEMATICAS, GEOGRAFIA, CIENCIAS, LENGUA_EXTRANJERA, DEPORTE, ARTES, INFORMATICA, HISTORIA, CIVICA, TUTORIA, VIDA_SALUDABLE) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?); ";
       
        try{
           CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
 cs.setString(1, getNombre());
 cs.setString(2, getApellidos());
 cs.setString(3, getMateria1());
 cs.setString(4, getMateria2());
 cs.setString(5, getMateria3());
 cs.setString(6, getMateria4());
 cs.setString(7, getMateria5());
 cs.setString(8, getMateria6());
 cs.setString(9, getMateria7());
 cs.setString(10, getMateria8());
 cs.setString(11, getMateria9());
 cs.setString(12, getMateria10());
 cs.setString(13, getMateria11());
 cs.setString(14, getMateria12());
 cs.execute();
 JOptionPane.showMessageDialog(null,"Se inserto correctamente");  
 
 } catch (Exception e){
 JOptionPane.showMessageDialog(null,"No se inserto correctamente"+e.toString());
 }
       

}
public void MostrarAlumnos1(JTable paramTablaCalificaciones){
Conexion objetoConexion = new Conexion();
     DefaultTableModel modelo = new DefaultTableModel();
     TableRowSorter<TableModel> OrdenarTabla = new TableRowSorter<TableModel> (modelo);
     paramTablaCalificaciones.setRowSorter(OrdenarTabla);
     String sql= "";
     modelo.addColumn("Id");
     modelo.addColumn("Nombre");
     modelo.addColumn("Apellidos");
     modelo.addColumn("Español");
     modelo.addColumn("Matematicas");
     modelo.addColumn("Geografia");
     modelo.addColumn("Ciencias");
     modelo.addColumn("Lengua_Extrangera");
     modelo.addColumn("Deporte");
     modelo.addColumn("Artes");
     modelo.addColumn("Informatica");
     modelo.addColumn("Historia");
     modelo.addColumn("Civica");
     modelo.addColumn("Tutoria");
     modelo.addColumn("Vida_Saludable");
     
     paramTablaCalificaciones.setModel(modelo);
     
     sql = "SELECT * FROM 1B;";
     String[] datos = new String [15];
     Statement st;
     
     try {
         st = objetoConexion.estableceConexion().createStatement();
         ResultSet rs = st.executeQuery(sql);
         while (rs.next()) {             
             datos[0] = rs.getString(1);
             datos[1] = rs.getString(2);
             datos[2] = rs.getString(3);
             datos[3] = rs.getString(4);
             datos[4] = rs.getString(5);
             datos[5] = rs.getString(6);
             datos[6] = rs.getString(7);
             datos[7] = rs.getString(8);
             datos[8] = rs.getString(9);
             datos[9] = rs.getString(10);
             datos[10] = rs.getString(11);
             datos[11] = rs.getString(12);
             datos[12] = rs.getString(13);
             datos[13] = rs.getString(14);  
             datos[14] = rs.getString(15);  
             
             modelo.addRow(datos);
         }
         paramTablaCalificaciones.setModel(modelo);
         
     } catch (Exception e) {
         JOptionPane.showMessageDialog(null, "No se pudo Mostrar los registos, error: " + e.toString());
     }
     
 }  
public void ModificarAlumnos1(JTextField paramCodigo, JTextField paramNombre,JTextField paramApellidos, JTextField paramMateria1, JTextField paramMateria2, JTextField paramMateria3, JTextField paramMateria4, JTextField paramMateria5, JTextField paramMateria6, JTextField paramMateria7, JTextField paramMateria8, JTextField paramMateria9, JTextField paramMateria10, JTextField paramMateria11, JTextField paramMateria12){
setCodigo(Integer.parseInt(paramCodigo.getText()));
setNombre(paramNombre.getText());
setApellidos(paramApellidos.getText());
setMateria1(paramMateria1.getText());
setMateria2(paramMateria2.getText());
setMateria3(paramMateria3.getText());
setMateria4(paramMateria4.getText());
setMateria5(paramMateria5.getText());
setMateria6(paramMateria6.getText());
setMateria7(paramMateria7.getText());
setMateria8(paramMateria8.getText());
setMateria9(paramMateria9.getText());
setMateria10(paramMateria10.getText());
setMateria11(paramMateria11.getText());
setMateria12(paramMateria12.getText());
Conexion objetoConexion = new Conexion();

String consulta = "UPDATE 1B SET 1B.NOMBRE = ?, 1B.APELLIDOS = ?, 1B.ESPAÑOL = ?, 1B.MATEMATICAS = ?, 1B.GEOGRAFIA = ?, 1B.CIENCIAS = ?, 1B.LENGUA_EXTRANJERA = ?, 1B.DEPORTE = ?, 1B.ARTES = ?, 1B.INFORMATICA = ?, 1B.HISTORIA = ?, 1B.CIVICA = ?, 1B.TUTORIA = ?, 1B.VIDA_SALUDABLE = ? WHERE 1B.ID = ?;";
    try {
        CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
        cs.setString(1, getNombre());
        cs.setString(2, getApellidos());
        cs.setString(3, getMateria1());
        cs.setString(4, getMateria2());
        cs.setString(5, getMateria3());
        cs.setString(6, getMateria4());
        cs.setString(7, getMateria5());
        cs.setString(8, getMateria6());
        cs.setString(9, getMateria7());
        cs.setString(10, getMateria8());
        cs.setString(11, getMateria9());
        cs.setString(12, getMateria10());
        cs.setString(13, getMateria11());
        cs.setString(14, getMateria12());
        cs.setInt(15, getCodigo());
        cs.execute();
        JOptionPane.showMessageDialog(null, "Modificacion Exitosa");
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al modificar, error: " + e.toString());
    }
}
public void EliminarAlumnos1(JTextField paramCodigo){
    setCodigo(Integer.parseInt(paramCodigo.getText()));
    Conexion objetoConexion = new Conexion();
    String consulta = "DELETE FROM 1B WHERE 1B.ID = ?";
    try{
        CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
        cs.setInt(1, getCodigo());
        cs.execute();
        JOptionPane.showMessageDialog(null, "Se elimino correctamente");
        
    } catch (SQLException e){
        JOptionPane.showMessageDialog(null, "No se pudo eliminar, error: " + e.toString());
    }
}
public void InsertarAlumnos2(JTextField paramNombre,JTextField paramApellidos, JTextField paramMateria1, JTextField paramMateria2, JTextField paramMateria3, JTextField paramMateria4, JTextField paramMateria5, JTextField paramMateria6, JTextField paramMateria7, JTextField paramMateria8, JTextField paramMateria9, JTextField paramMateria10, JTextField paramMateria11, JTextField paramMateria12){
    
        setNombre(paramNombre.getText());
        setApellidos(paramApellidos.getText());
        setMateria1(paramMateria1.getText());
        setMateria2(paramMateria2.getText());
        setMateria3(paramMateria3.getText());
        setMateria4(paramMateria4.getText());
        setMateria5(paramMateria5.getText());
        setMateria6(paramMateria6.getText());
        setMateria7(paramMateria7.getText());
        setMateria8(paramMateria8.getText());
        setMateria9(paramMateria9.getText());
        setMateria10(paramMateria10.getText());
        setMateria11(paramMateria11.getText());
        setMateria12(paramMateria12.getText());    
        Conexion objetoConexion = new Conexion();
        String consulta ="INSERT INTO 1C(NOMBRE, APELLIDOS, ESPAÑOL, MATEMATICAS, GEOGRAFIA, CIENCIAS, LENGUA_EXTRANJERA, EDUC_FISICA, ARTES, TECNOLOGIA, HISTORIA, CIVICA, TUTORIA, VIDA_SALUDABLE) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?); ";
       
        try{
           CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
 cs.setString(1, getNombre());
 cs.setString(2, getApellidos());
 cs.setString(3, getMateria1());
 cs.setString(4, getMateria2());
 cs.setString(5, getMateria3());
 cs.setString(6, getMateria4());
 cs.setString(7, getMateria5());
 cs.setString(8, getMateria6());
 cs.setString(9, getMateria7());
 cs.setString(10, getMateria8());
 cs.setString(11, getMateria9());
 cs.setString(12, getMateria10());
 cs.setString(13, getMateria11());
 cs.setString(14, getMateria12());
 cs.execute();
 JOptionPane.showMessageDialog(null,"Se inserto correctamente");  
 
 } catch (Exception e){
 JOptionPane.showMessageDialog(null,"No se inserto correctamente"+e.toString());
 }
       

}
public void MostrarAlumnos2(JTable paramTablaCalificaciones){
Conexion objetoConexion = new Conexion();
     DefaultTableModel modelo = new DefaultTableModel();
     TableRowSorter<TableModel> OrdenarTabla = new TableRowSorter<TableModel> (modelo);
     paramTablaCalificaciones.setRowSorter(OrdenarTabla);
     String sql= "";
     modelo.addColumn("Id");
     modelo.addColumn("Nombre");
     modelo.addColumn("Apellidos");
     modelo.addColumn("Español");
     modelo.addColumn("Matematicas");
     modelo.addColumn("Geografia");
     modelo.addColumn("Ciencias");
     modelo.addColumn("Lengua_Extrangera");
     modelo.addColumn("Educ_Fisica");
     modelo.addColumn("Artes");
     modelo.addColumn("Tecnologia");
     modelo.addColumn("Historia");
     modelo.addColumn("Civica");
     modelo.addColumn("Tutoria");
     modelo.addColumn("Vida_Saludable");
     
     paramTablaCalificaciones.setModel(modelo);
     
     sql = "SELECT * FROM 1C;";
     String[] datos = new String [15];
     Statement st;
     
     try {
         st = objetoConexion.estableceConexion().createStatement();
         ResultSet rs = st.executeQuery(sql);
         while (rs.next()) {             
             datos[0] = rs.getString(1);
             datos[1] = rs.getString(2);
             datos[2] = rs.getString(3);
             datos[3] = rs.getString(4);
             datos[4] = rs.getString(5);
             datos[5] = rs.getString(6);
             datos[6] = rs.getString(7);
             datos[7] = rs.getString(8);
             datos[8] = rs.getString(9);
             datos[9] = rs.getString(10);
             datos[10] = rs.getString(11);
             datos[11] = rs.getString(12);
             datos[12] = rs.getString(13);
             datos[13] = rs.getString(14);  
             datos[14] = rs.getString(15);  
             
             modelo.addRow(datos);
         }
         paramTablaCalificaciones.setModel(modelo);
         
     } catch (Exception e) {
         JOptionPane.showMessageDialog(null, "No se pudo Mostrar los registos, error: " + e.toString());
     }
     
 } 
public void ModificarAlumnos2(JTextField paramCodigo, JTextField paramNombre,JTextField paramApellidos, JTextField paramMateria1, JTextField paramMateria2, JTextField paramMateria3, JTextField paramMateria4, JTextField paramMateria5, JTextField paramMateria6, JTextField paramMateria7, JTextField paramMateria8, JTextField paramMateria9, JTextField paramMateria10, JTextField paramMateria11, JTextField paramMateria12){
setCodigo(Integer.parseInt(paramCodigo.getText()));
setNombre(paramNombre.getText());
setApellidos(paramApellidos.getText());
setMateria1(paramMateria1.getText());
setMateria2(paramMateria2.getText());
setMateria3(paramMateria3.getText());
setMateria4(paramMateria4.getText());
setMateria5(paramMateria5.getText());
setMateria6(paramMateria6.getText());
setMateria7(paramMateria7.getText());
setMateria8(paramMateria8.getText());
setMateria9(paramMateria9.getText());
setMateria10(paramMateria10.getText());
setMateria11(paramMateria11.getText());
setMateria12(paramMateria12.getText());
Conexion objetoConexion = new Conexion();

String consulta = "UPDATE 1C SET 1C.NOMBRE = ?, 1C.APELLIDOS = ?, 1C.ESPAÑOL = ?, 1C.MATEMATICAS = ?, 1C.GEOGRAFIA = ?, 1C.CIENCIAS = ?, 1C.LENGUA_EXTRANJERA = ?, 1C.EDUC_FISICA = ?, 1C.ARTES = ?, 1C.TECNOLOGIA = ?, 1C.HISTORIA = ?, 1C.CIVICA = ?, 1C.TUTORIA = ?, 1C.VIDA_SALUDABLE = ? WHERE 1C.ID = ?;";
    try {
        CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
        cs.setString(1, getNombre());
        cs.setString(2, getApellidos());
        cs.setString(3, getMateria1());
        cs.setString(4, getMateria2());
        cs.setString(5, getMateria3());
        cs.setString(6, getMateria4());
        cs.setString(7, getMateria5());
        cs.setString(8, getMateria6());
        cs.setString(9, getMateria7());
        cs.setString(10, getMateria8());
        cs.setString(11, getMateria9());
        cs.setString(12, getMateria10());
        cs.setString(13, getMateria11());
        cs.setString(14, getMateria12());
        cs.setInt(15, getCodigo());
        cs.execute();
        JOptionPane.showMessageDialog(null, "Modificacion Exitosa");
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al modificar, error: " + e.toString());
    }
}
public void EliminarAlumnos2(JTextField paramCodigo){
    setCodigo(Integer.parseInt(paramCodigo.getText()));
    Conexion objetoConexion = new Conexion();
    String consulta = "DELETE FROM 1C WHERE 1C.ID = ?";
    try{
        CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
        cs.setInt(1, getCodigo());
        cs.execute();
        JOptionPane.showMessageDialog(null, "Se elimino correctamente");
        
    } catch (SQLException e){
        JOptionPane.showMessageDialog(null, "No se pudo eliminar, error: " + e.toString());
    }
}
public void InsertarAlumnos3(JTextField paramNombre,JTextField paramApellidos, JTextField paramMateria1, JTextField paramMateria2, JTextField paramMateria3, JTextField paramMateria4, JTextField paramMateria5, JTextField paramMateria6, JTextField paramMateria7, JTextField paramMateria8, JTextField paramMateria9, JTextField paramMateria10, JTextField paramMateria11, JTextField paramMateria12){
    
        setNombre(paramNombre.getText());
        setApellidos(paramApellidos.getText());
        setMateria1(paramMateria1.getText());
        setMateria2(paramMateria2.getText());
        setMateria3(paramMateria3.getText());
        setMateria4(paramMateria4.getText());
        setMateria5(paramMateria5.getText());
        setMateria6(paramMateria6.getText());
        setMateria7(paramMateria7.getText());
        setMateria8(paramMateria8.getText());
        setMateria9(paramMateria9.getText());
        setMateria10(paramMateria10.getText());
        setMateria11(paramMateria11.getText());
        setMateria12(paramMateria12.getText());    
        Conexion objetoConexion = new Conexion();
        String consulta ="INSERT INTO 1D(NOMBRE, APELLIDOS, ESPAÑOL, MATEMATICAS, GEOGRAFIA, CIENCIAS, LENGUA_EXTRANJERA, EDUC_FISICA, ARTES, TECNOLOGIA, HISTORIA, CIVICA, TUTORIA, VIDA_SALUDABLE) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?); ";
       
        try{
           CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
 cs.setString(1, getNombre());
 cs.setString(2, getApellidos());
 cs.setString(3, getMateria1());
 cs.setString(4, getMateria2());
 cs.setString(5, getMateria3());
 cs.setString(6, getMateria4());
 cs.setString(7, getMateria5());
 cs.setString(8, getMateria6());
 cs.setString(9, getMateria7());
 cs.setString(10, getMateria8());
 cs.setString(11, getMateria9());
 cs.setString(12, getMateria10());
 cs.setString(13, getMateria11());
 cs.setString(14, getMateria12());
 cs.execute();
 JOptionPane.showMessageDialog(null,"Se inserto correctamente");  
 
 } catch (Exception e){
 JOptionPane.showMessageDialog(null,"No se inserto correctamente"+e.toString());
 }
       

}
public void MostrarAlumnos3(JTable paramTablaCalificaciones){
Conexion objetoConexion = new Conexion();
     DefaultTableModel modelo = new DefaultTableModel();
     TableRowSorter<TableModel> OrdenarTabla = new TableRowSorter<TableModel> (modelo);
     paramTablaCalificaciones.setRowSorter(OrdenarTabla);
     String sql= "";
     modelo.addColumn("Id");
     modelo.addColumn("Nombre");
     modelo.addColumn("Apellidos");
     modelo.addColumn("Español");
     modelo.addColumn("Matematicas");
     modelo.addColumn("Geografia");
     modelo.addColumn("Ciencias");
     modelo.addColumn("Lengua_Extrangera");
     modelo.addColumn("Educ_Fisica");
     modelo.addColumn("Artes");
     modelo.addColumn("Tecnologia");
     modelo.addColumn("Historia");
     modelo.addColumn("Civica");
     modelo.addColumn("Tutoria");
     modelo.addColumn("Vida_Saludable");
     
     paramTablaCalificaciones.setModel(modelo);
     
     sql = "SELECT * FROM 1D;";
     String[] datos = new String [15];
     Statement st;
     
     try {
         st = objetoConexion.estableceConexion().createStatement();
         ResultSet rs = st.executeQuery(sql);
         while (rs.next()) {             
             datos[0] = rs.getString(1);
             datos[1] = rs.getString(2);
             datos[2] = rs.getString(3);
             datos[3] = rs.getString(4);
             datos[4] = rs.getString(5);
             datos[5] = rs.getString(6);
             datos[6] = rs.getString(7);
             datos[7] = rs.getString(8);
             datos[8] = rs.getString(9);
             datos[9] = rs.getString(10);
             datos[10] = rs.getString(11);
             datos[11] = rs.getString(12);
             datos[12] = rs.getString(13);
             datos[13] = rs.getString(14);  
             datos[14] = rs.getString(15);
             
             modelo.addRow(datos);
         }
         paramTablaCalificaciones.setModel(modelo);
         
     } catch (Exception e) {
         JOptionPane.showMessageDialog(null, "No se pudo Mostrar los registos, error: " + e.toString());
     }
     
 }  
public void ModificarAlumnos3(JTextField paramCodigo, JTextField paramNombre,JTextField paramApellidos, JTextField paramMateria1, JTextField paramMateria2, JTextField paramMateria3, JTextField paramMateria4, JTextField paramMateria5, JTextField paramMateria6, JTextField paramMateria7, JTextField paramMateria8, JTextField paramMateria9, JTextField paramMateria10, JTextField paramMateria11, JTextField paramMateria12){
setCodigo(Integer.parseInt(paramCodigo.getText()));
setNombre(paramNombre.getText());
setApellidos(paramApellidos.getText());
setMateria1(paramMateria1.getText());
setMateria2(paramMateria2.getText());
setMateria3(paramMateria3.getText());
setMateria4(paramMateria4.getText());
setMateria5(paramMateria5.getText());
setMateria6(paramMateria6.getText());
setMateria7(paramMateria7.getText());
setMateria8(paramMateria8.getText());
setMateria9(paramMateria9.getText());
setMateria10(paramMateria10.getText());
setMateria11(paramMateria11.getText());
setMateria12(paramMateria12.getText());
Conexion objetoConexion = new Conexion();

String consulta = "UPDATE 1D SET 1D.NOMBRE = ?, 1D.APELLIDOS = ?, 1D.ESPAÑOL = ?, 1D.MATEMATICAS = ?, 1D.GEOGRAFIA = ?, 1D.CIENCIAS = ?, 1D.LENGUA_EXTRANJERA = ?, 1D.EDUC_FISICA = ?, 1D.ARTES = ?, 1D.TECNOLOGIA = ?, 1D.HISTORIA = ?, 1C.CIVICA = ?, 1D.TUTORIA = ?, 1D.VIDA_SALUDABLE = ? WHERE 1D.ID = ?;";
    try {
        CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
        cs.setString(1, getNombre());
        cs.setString(2, getApellidos());
        cs.setString(3, getMateria1());
        cs.setString(4, getMateria2());
        cs.setString(5, getMateria3());
        cs.setString(6, getMateria4());
        cs.setString(7, getMateria5());
        cs.setString(8, getMateria6());
        cs.setString(9, getMateria7());
        cs.setString(10, getMateria8());
        cs.setString(11, getMateria9());
        cs.setString(12, getMateria10());
        cs.setString(13, getMateria11());
        cs.setString(14, getMateria12());
        cs.setInt(15, getCodigo());
        cs.execute();
        JOptionPane.showMessageDialog(null, "Modificacion Exitosa");
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al modificar, error: " + e.toString());
    }
}
public void EliminarAlumnos3(JTextField paramCodigo){
    setCodigo(Integer.parseInt(paramCodigo.getText()));
    Conexion objetoConexion = new Conexion();
    String consulta = "DELETE FROM 1D WHERE 1D.ID = ?";
    try{
        CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
        cs.setInt(1, getCodigo());
        cs.execute();
        JOptionPane.showMessageDialog(null, "Se elimino correctamente");
        
    } catch (SQLException e){
        JOptionPane.showMessageDialog(null, "No se pudo eliminar, error: " + e.toString());
    }
}
public void InsertarAlumnos4(JTextField paramNombre,JTextField paramApellidos, JTextField paramMateria1, JTextField paramMateria2, JTextField paramMateria3, JTextField paramMateria4, JTextField paramMateria5, JTextField paramMateria6, JTextField paramMateria7, JTextField paramMateria8, JTextField paramMateria9, JTextField paramMateria10, JTextField paramMateria11, JTextField paramMateria12){
    
        setNombre(paramNombre.getText());
        setApellidos(paramApellidos.getText());
        setMateria1(paramMateria1.getText());
        setMateria2(paramMateria2.getText());
        setMateria3(paramMateria3.getText());
        setMateria4(paramMateria4.getText());
        setMateria5(paramMateria5.getText());
        setMateria6(paramMateria6.getText());
        setMateria7(paramMateria7.getText());
        setMateria8(paramMateria8.getText());
        setMateria9(paramMateria9.getText());
        setMateria10(paramMateria10.getText());
        setMateria11(paramMateria11.getText());
        setMateria12(paramMateria12.getText());    
        Conexion objetoConexion = new Conexion();
        String consulta ="INSERT INTO 2A(NOMBRE, APELLIDOS, ESPAÑOL, MATEMATICAS, CIVICA, CIENCIAS, LENGUA_EXTRANJERA, DEPORTE, ARTES, TECNOLOGIA, HISTORIA, TUTORIA, VIDA_SALUDABLE, EQUIDAD_DE_GENERO) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?); ";
       
        try{
           CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
 cs.setString(1, getNombre());
 cs.setString(2, getApellidos());
 cs.setString(3, getMateria1());
 cs.setString(4, getMateria2());
 cs.setString(5, getMateria3());
 cs.setString(6, getMateria4());
 cs.setString(7, getMateria5());
 cs.setString(8, getMateria6());
 cs.setString(9, getMateria7());
 cs.setString(10, getMateria8());
 cs.setString(11, getMateria9());
 cs.setString(12, getMateria10());
 cs.setString(13, getMateria11());
 cs.setString(14, getMateria12());
 cs.execute();
 JOptionPane.showMessageDialog(null,"Se inserto correctamente");  
 
 } catch (Exception e){
 JOptionPane.showMessageDialog(null,"No se inserto correctamente"+e.toString());
 }
       

}
public void MostrarAlumnos4(JTable paramTablaCalificaciones){
Conexion objetoConexion = new Conexion();
     DefaultTableModel modelo = new DefaultTableModel();
     TableRowSorter<TableModel> OrdenarTabla = new TableRowSorter<TableModel> (modelo);
     paramTablaCalificaciones.setRowSorter(OrdenarTabla);
     String sql= "";
     modelo.addColumn("Id");
     modelo.addColumn("Nombre");
     modelo.addColumn("Apellidos");
     modelo.addColumn("Español");
     modelo.addColumn("Matematicas");
     modelo.addColumn("Civica");
     modelo.addColumn("Ciencias");
     modelo.addColumn("Lengua_Extrangera");
     modelo.addColumn("Deporte");
     modelo.addColumn("Artes");
     modelo.addColumn("Tecnologia");
     modelo.addColumn("Historia");
     modelo.addColumn("Tutoria");
     modelo.addColumn("Vida_Saludablue");
     modelo.addColumn("Equidad_De_Genero");
     
     paramTablaCalificaciones.setModel(modelo);
     
     sql = "SELECT * FROM 2A;";
     String[] datos = new String [15];
     Statement st;
     
     try {
         st = objetoConexion.estableceConexion().createStatement();
         ResultSet rs = st.executeQuery(sql);
         while (rs.next()) {             
             datos[0] = rs.getString(1);
             datos[1] = rs.getString(2);
             datos[2] = rs.getString(3);
             datos[3] = rs.getString(4);
             datos[4] = rs.getString(5);
             datos[5] = rs.getString(6);
             datos[6] = rs.getString(7);
             datos[7] = rs.getString(8);
             datos[8] = rs.getString(9);
             datos[9] = rs.getString(10);
             datos[10] = rs.getString(11);
             datos[11] = rs.getString(12);
             datos[12] = rs.getString(13);
             datos[13] = rs.getString(14);  
             datos[14] = rs.getString(15);  
             
             modelo.addRow(datos);
         }
         paramTablaCalificaciones.setModel(modelo);
         
     } catch (Exception e) {
         JOptionPane.showMessageDialog(null, "No se pudo Mostrar los registos, error: " + e.toString());
     }
     
 }  
public void ModificarAlumnos4(JTextField paramCodigo, JTextField paramNombre,JTextField paramApellidos, JTextField paramMateria1, JTextField paramMateria2, JTextField paramMateria3, JTextField paramMateria4, JTextField paramMateria5, JTextField paramMateria6, JTextField paramMateria7, JTextField paramMateria8, JTextField paramMateria9, JTextField paramMateria10, JTextField paramMateria11, JTextField paramMateria12){
setCodigo(Integer.parseInt(paramCodigo.getText()));
setNombre(paramNombre.getText());
setApellidos(paramApellidos.getText());
setMateria1(paramMateria1.getText());
setMateria2(paramMateria2.getText());
setMateria3(paramMateria3.getText());
setMateria4(paramMateria4.getText());
setMateria5(paramMateria5.getText());
setMateria6(paramMateria6.getText());
setMateria7(paramMateria7.getText());
setMateria8(paramMateria8.getText());
setMateria9(paramMateria9.getText());
setMateria10(paramMateria10.getText());
setMateria11(paramMateria11.getText());
setMateria12(paramMateria12.getText());
Conexion objetoConexion = new Conexion();

String consulta = "UPDATE 2A SET 2A.NOMBRE = ?, 2A.APELLIDOS = ?, 2A.ESPAÑOL = ?, 2A.MATEMATICAS = ?, 2A.CIVICA = ?, 2A.CIENCIAS = ?, 2A.LENGUA_EXTRANJERA = ?, 2A.DEPORTE = ?, 2A.ARTES = ?, 2A.TECNOLOGIA = ?, 2A.HISTORIA = ?, 2A.TUTORIA = ?, 2A.VIDA_SALUDABLE = ?, 2A.EQUIDAD_DE_GENERO = ? WHERE 2A.ID = ?;";
    try {
        CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
        cs.setString(1, getNombre());
        cs.setString(2, getApellidos());
        cs.setString(3, getMateria1());
        cs.setString(4, getMateria2());
        cs.setString(5, getMateria3());
        cs.setString(6, getMateria4());
        cs.setString(7, getMateria5());
        cs.setString(8, getMateria6());
        cs.setString(9, getMateria7());
        cs.setString(10, getMateria8());
        cs.setString(11, getMateria9());
        cs.setString(12, getMateria10());
        cs.setString(13, getMateria11());
        cs.setString(14, getMateria12());
        cs.setInt(15, getCodigo());
        cs.execute();
        JOptionPane.showMessageDialog(null, "Modificacion Exitosa");
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al modificar, error: " + e.toString());
    }
}
public void EliminarAlumnos4(JTextField paramCodigo){
    setCodigo(Integer.parseInt(paramCodigo.getText()));
    Conexion objetoConexion = new Conexion();
    String consulta = "DELETE FROM 2A WHERE 2A.ID = ?";
    try{
        CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
        cs.setInt(1, getCodigo());
        cs.execute();
        JOptionPane.showMessageDialog(null, "Se elimino correctamente");
        
    } catch (SQLException e){
        JOptionPane.showMessageDialog(null, "No se pudo eliminar, error: " + e.toString());
    }
}
public void InsertarAlumnos5(JTextField paramNombre,JTextField paramApellidos, JTextField paramMateria1, JTextField paramMateria2, JTextField paramMateria3, JTextField paramMateria4, JTextField paramMateria5, JTextField paramMateria6, JTextField paramMateria7, JTextField paramMateria8, JTextField paramMateria9, JTextField paramMateria10, JTextField paramMateria11, JTextField paramMateria12){
    
        setNombre(paramNombre.getText());
        setApellidos(paramApellidos.getText());
        setMateria1(paramMateria1.getText());
        setMateria2(paramMateria2.getText());
        setMateria3(paramMateria3.getText());
        setMateria4(paramMateria4.getText());
        setMateria5(paramMateria5.getText());
        setMateria6(paramMateria6.getText());
        setMateria7(paramMateria7.getText());
        setMateria8(paramMateria8.getText());
        setMateria9(paramMateria9.getText());
        setMateria10(paramMateria10.getText());
        setMateria11(paramMateria11.getText());
        setMateria12(paramMateria12.getText());    
        Conexion objetoConexion = new Conexion();
        String consulta ="INSERT INTO 2B(NOMBRE, APELLIDOS, ESPAÑOL, MATEMATICAS, CIVICA, CIENCIAS, LENGUA_EXTRANJERA, DEPORTE, ARTES, TECNOLOGIA, HISTORIA, TUTORIA, VIDA_SALUDABLE, EQUIDAD_DE_GENERO) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?); ";
       
        try{
           CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
 cs.setString(1, getNombre());
 cs.setString(2, getApellidos());
 cs.setString(3, getMateria1());
 cs.setString(4, getMateria2());
 cs.setString(5, getMateria3());
 cs.setString(6, getMateria4());
 cs.setString(7, getMateria5());
 cs.setString(8, getMateria6());
 cs.setString(9, getMateria7());
 cs.setString(10, getMateria8());
 cs.setString(11, getMateria9());
 cs.setString(12, getMateria10());
 cs.setString(13, getMateria11());
 cs.setString(14, getMateria12());
 cs.execute();
 JOptionPane.showMessageDialog(null,"Se inserto correctamente");  
 
 } catch (Exception e){
 JOptionPane.showMessageDialog(null,"No se inserto correctamente"+e.toString());
 }
       

}
public void MostrarAlumnos5(JTable paramTablaCalificaciones){
Conexion objetoConexion = new Conexion();
     DefaultTableModel modelo = new DefaultTableModel();
     TableRowSorter<TableModel> OrdenarTabla = new TableRowSorter<TableModel> (modelo);
     paramTablaCalificaciones.setRowSorter(OrdenarTabla);
     String sql= "";
     modelo.addColumn("Id");
     modelo.addColumn("Nombre");
     modelo.addColumn("Apellidos");
     modelo.addColumn("Español");
     modelo.addColumn("Matematicas");
     modelo.addColumn("Civica");
     modelo.addColumn("Ciencias");
     modelo.addColumn("Lengua_Extrangera");
     modelo.addColumn("Deporte");
     modelo.addColumn("Artes");
     modelo.addColumn("Tecnologia");
     modelo.addColumn("Historia");
     modelo.addColumn("Tutoria");
     modelo.addColumn("Vida_Saludablue");
     modelo.addColumn("Equidad_De_Genero");
     
     paramTablaCalificaciones.setModel(modelo);
     
     sql = "SELECT * FROM 2B;";
     String[] datos = new String [15];
     Statement st;
     
     try {
         st = objetoConexion.estableceConexion().createStatement();
         ResultSet rs = st.executeQuery(sql);
         while (rs.next()) {             
             datos[0] = rs.getString(1);
             datos[1] = rs.getString(2);
             datos[2] = rs.getString(3);
             datos[3] = rs.getString(4);
             datos[4] = rs.getString(5);
             datos[5] = rs.getString(6);
             datos[6] = rs.getString(7);
             datos[7] = rs.getString(8);
             datos[8] = rs.getString(9);
             datos[9] = rs.getString(10);
             datos[10] = rs.getString(11);
             datos[11] = rs.getString(12);
             datos[12] = rs.getString(13);
             datos[13] = rs.getString(14);  
             datos[14] = rs.getString(15);  
             
             modelo.addRow(datos);
         }
         paramTablaCalificaciones.setModel(modelo);
         
     } catch (Exception e) {
         JOptionPane.showMessageDialog(null, "No se pudo Mostrar los registos, error: " + e.toString());
     }
     
 }  
public void ModificarAlumnos5(JTextField paramCodigo, JTextField paramNombre,JTextField paramApellidos, JTextField paramMateria1, JTextField paramMateria2, JTextField paramMateria3, JTextField paramMateria4, JTextField paramMateria5, JTextField paramMateria6, JTextField paramMateria7, JTextField paramMateria8, JTextField paramMateria9, JTextField paramMateria10, JTextField paramMateria11, JTextField paramMateria12){
setCodigo(Integer.parseInt(paramCodigo.getText()));
setNombre(paramNombre.getText());
setApellidos(paramApellidos.getText());
setMateria1(paramMateria1.getText());
setMateria2(paramMateria2.getText());
setMateria3(paramMateria3.getText());
setMateria4(paramMateria4.getText());
setMateria5(paramMateria5.getText());
setMateria6(paramMateria6.getText());
setMateria7(paramMateria7.getText());
setMateria8(paramMateria8.getText());
setMateria9(paramMateria9.getText());
setMateria10(paramMateria10.getText());
setMateria11(paramMateria11.getText());
setMateria12(paramMateria12.getText());
Conexion objetoConexion = new Conexion();

String consulta = "UPDATE 2B SET 2B.NOMBRE = ?, 2B.APELLIDOS = ?, 2B.ESPAÑOL = ?, 2B.MATEMATICAS = ?, 2B.CIVICA = ?, 2B.CIENCIAS = ?, 2B.LENGUA_EXTRANJERA = ?, 2B.DEPORTE = ?, 2B.ARTES = ?, 2B.TECNOLOGIA = ?, 2B.HISTORIA = ?, 2B.TUTORIA = ?, 2B.VIDA_SALUDABLE = ?, 2B.EQUIDAD_DE_GENERO = ? WHERE 2B.ID = ?;";
    try {
        CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
        cs.setString(1, getNombre());
        cs.setString(2, getApellidos());
        cs.setString(3, getMateria1());
        cs.setString(4, getMateria2());
        cs.setString(5, getMateria3());
        cs.setString(6, getMateria4());
        cs.setString(7, getMateria5());
        cs.setString(8, getMateria6());
        cs.setString(9, getMateria7());
        cs.setString(10, getMateria8());
        cs.setString(11, getMateria9());
        cs.setString(12, getMateria10());
        cs.setString(13, getMateria11());
        cs.setString(14, getMateria12());
        cs.setInt(15, getCodigo());
        cs.execute();
        JOptionPane.showMessageDialog(null, "Modificacion Exitosa");
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al modificar, error: " + e.toString());
    }
}
public void EliminarAlumnos5(JTextField paramCodigo){
    setCodigo(Integer.parseInt(paramCodigo.getText()));
    Conexion objetoConexion = new Conexion();
    String consulta = "DELETE FROM 2B WHERE 2B.ID = ?";
    try{
        CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
        cs.setInt(1, getCodigo());
        cs.execute();
        JOptionPane.showMessageDialog(null, "Se elimino correctamente");
        
    } catch (SQLException e){
        JOptionPane.showMessageDialog(null, "No se pudo eliminar, error: " + e.toString());
    }
}
public void InsertarAlumnos6(JTextField paramNombre,JTextField paramApellidos, JTextField paramMateria1, JTextField paramMateria2, JTextField paramMateria3, JTextField paramMateria4, JTextField paramMateria5, JTextField paramMateria6, JTextField paramMateria7, JTextField paramMateria8, JTextField paramMateria9, JTextField paramMateria10, JTextField paramMateria11, JTextField paramMateria12){
    
        setNombre(paramNombre.getText());
        setApellidos(paramApellidos.getText());
        setMateria1(paramMateria1.getText());
        setMateria2(paramMateria2.getText());
        setMateria3(paramMateria3.getText());
        setMateria4(paramMateria4.getText());
        setMateria5(paramMateria5.getText());
        setMateria6(paramMateria6.getText());
        setMateria7(paramMateria7.getText());
        setMateria8(paramMateria8.getText());
        setMateria9(paramMateria9.getText());
        setMateria10(paramMateria10.getText());
        setMateria11(paramMateria11.getText());
        setMateria12(paramMateria12.getText());    
        Conexion objetoConexion = new Conexion();
        String consulta ="INSERT INTO 2C(NOMBRE, APELLIDOS, ESPAÑOL, MATEMATICAS, CIVICA, CIENCIAS, LENGUA_EXTRANJERA, DEPORTE, ARTES, TECNOLOGIA, HISTORIA, TUTORIA, VIDA_SALUDABLE, EQUIDAD_DE_GENERO) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?); ";
       
        try{
           CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
 cs.setString(1, getNombre());
 cs.setString(2, getApellidos());
 cs.setString(3, getMateria1());
 cs.setString(4, getMateria2());
 cs.setString(5, getMateria3());
 cs.setString(6, getMateria4());
 cs.setString(7, getMateria5());
 cs.setString(8, getMateria6());
 cs.setString(9, getMateria7());
 cs.setString(10, getMateria8());
 cs.setString(11, getMateria9());
 cs.setString(12, getMateria10());
 cs.setString(13, getMateria11());
 cs.setString(14, getMateria12());
 cs.execute();
 JOptionPane.showMessageDialog(null,"Se inserto correctamente");  
 
 } catch (Exception e){
 JOptionPane.showMessageDialog(null,"No se inserto correctamente"+e.toString());
 }
       

}
public void MostrarAlumnos6(JTable paramTablaCalificaciones){
Conexion objetoConexion = new Conexion();
     DefaultTableModel modelo = new DefaultTableModel();
     TableRowSorter<TableModel> OrdenarTabla = new TableRowSorter<TableModel> (modelo);
     paramTablaCalificaciones.setRowSorter(OrdenarTabla);
     String sql= "";
     modelo.addColumn("Id");
     modelo.addColumn("Nombre");
     modelo.addColumn("Apellidos");
     modelo.addColumn("Español");
     modelo.addColumn("Matematicas");
     modelo.addColumn("Civica");
     modelo.addColumn("Ciencias");
     modelo.addColumn("Lengua_Extrangera");
     modelo.addColumn("Deporte");
     modelo.addColumn("Artes");
     modelo.addColumn("Tecnologia");
     modelo.addColumn("Historia");
     modelo.addColumn("Tutoria");
     modelo.addColumn("Vida_Saludablue");
     modelo.addColumn("Equidad_De_Genero");
     
     paramTablaCalificaciones.setModel(modelo);
     
     sql = "SELECT * FROM 2C;";
     String[] datos = new String [15];
     Statement st;
     
     try {
         st = objetoConexion.estableceConexion().createStatement();
         ResultSet rs = st.executeQuery(sql);
         while (rs.next()) {             
             datos[0] = rs.getString(1);
             datos[1] = rs.getString(2);
             datos[2] = rs.getString(3);
             datos[3] = rs.getString(4);
             datos[4] = rs.getString(5);
             datos[5] = rs.getString(6);
             datos[6] = rs.getString(7);
             datos[7] = rs.getString(8);
             datos[8] = rs.getString(9);
             datos[9] = rs.getString(10);
             datos[10] = rs.getString(11);
             datos[11] = rs.getString(12);
             datos[12] = rs.getString(13);
             datos[13] = rs.getString(14);  
             datos[14] = rs.getString(15);  
             
             modelo.addRow(datos);
         }
         paramTablaCalificaciones.setModel(modelo);
         
     } catch (Exception e) {
         JOptionPane.showMessageDialog(null, "No se pudo Mostrar los registos, error: " + e.toString());
     }
     
 }
public void ModificarAlumnos6(JTextField paramCodigo, JTextField paramNombre,JTextField paramApellidos, JTextField paramMateria1, JTextField paramMateria2, JTextField paramMateria3, JTextField paramMateria4, JTextField paramMateria5, JTextField paramMateria6, JTextField paramMateria7, JTextField paramMateria8, JTextField paramMateria9, JTextField paramMateria10, JTextField paramMateria11, JTextField paramMateria12){
setCodigo(Integer.parseInt(paramCodigo.getText()));
setNombre(paramNombre.getText());
setApellidos(paramApellidos.getText());
setMateria1(paramMateria1.getText());
setMateria2(paramMateria2.getText());
setMateria3(paramMateria3.getText());
setMateria4(paramMateria4.getText());
setMateria5(paramMateria5.getText());
setMateria6(paramMateria6.getText());
setMateria7(paramMateria7.getText());
setMateria8(paramMateria8.getText());
setMateria9(paramMateria9.getText());
setMateria10(paramMateria10.getText());
setMateria11(paramMateria11.getText());
setMateria12(paramMateria12.getText());
Conexion objetoConexion = new Conexion();

String consulta = "UPDATE 2C SET 2C.NOMBRE = ?, 2C.APELLIDOS = ?, 2C.ESPAÑOL = ?, 2C.MATEMATICAS = ?, 2C.CIVICA = ?, 2C.CIENCIAS = ?, 2C.LENGUA_EXTRANJERA = ?, 2C.DEPORTE = ?, 2C.ARTES = ?, 2C.TECNOLOGIA = ?, 2C.HISTORIA = ?, 2C.TUTORIA = ?, 2C.VIDA_SALUDABLE = ?, 2C.EQUIDAD_DE_GENERO = ? WHERE 2C.ID = ?;";
    try {
        CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
        cs.setString(1, getNombre());
        cs.setString(2, getApellidos());
        cs.setString(3, getMateria1());
        cs.setString(4, getMateria2());
        cs.setString(5, getMateria3());
        cs.setString(6, getMateria4());
        cs.setString(7, getMateria5());
        cs.setString(8, getMateria6());
        cs.setString(9, getMateria7());
        cs.setString(10, getMateria8());
        cs.setString(11, getMateria9());
        cs.setString(12, getMateria10());
        cs.setString(13, getMateria11());
        cs.setString(14, getMateria12());
        cs.setInt(15, getCodigo());
        cs.execute();
        JOptionPane.showMessageDialog(null, "Modificacion Exitosa");
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al modificar, error: " + e.toString());
    }
}
public void EliminarAlumnos6(JTextField paramCodigo){
    setCodigo(Integer.parseInt(paramCodigo.getText()));
    Conexion objetoConexion = new Conexion();
    String consulta = "DELETE FROM 2C WHERE 2C.ID = ?";
    try{
        CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
        cs.setInt(1, getCodigo());
        cs.execute();
        JOptionPane.showMessageDialog(null, "Se elimino correctamente");
        
    } catch (SQLException e){
        JOptionPane.showMessageDialog(null, "No se pudo eliminar, error: " + e.toString());
    }
}
public void InsertarAlumnos7(JTextField paramNombre,JTextField paramApellidos, JTextField paramMateria1, JTextField paramMateria2, JTextField paramMateria3, JTextField paramMateria4, JTextField paramMateria5, JTextField paramMateria6, JTextField paramMateria7, JTextField paramMateria8, JTextField paramMateria9, JTextField paramMateria10, JTextField paramMateria11, JTextField paramMateria12){
    
        setNombre(paramNombre.getText());
        setApellidos(paramApellidos.getText());
        setMateria1(paramMateria1.getText());
        setMateria2(paramMateria2.getText());
        setMateria3(paramMateria3.getText());
        setMateria4(paramMateria4.getText());
        setMateria5(paramMateria5.getText());
        setMateria6(paramMateria6.getText());
        setMateria7(paramMateria7.getText());
        setMateria8(paramMateria8.getText());
        setMateria9(paramMateria9.getText());
        setMateria10(paramMateria10.getText());
        setMateria11(paramMateria11.getText());
        setMateria12(paramMateria12.getText());    
        Conexion objetoConexion = new Conexion();
        String consulta ="INSERT INTO 3A(NOMBRE, APELLIDOS, ESPAÑOL, MATEMATICAS, CIVICA, CIENCIAS, LENGUA_EXTRANJERA, DEPORTE, ARTES, TECNOLOGIA, HISTORIA, TUTORIA, VIDA_SALUDABLE, EQUIDAD_DE_GENERO) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?); ";
       
        try{
           CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
 cs.setString(1, getNombre());
 cs.setString(2, getApellidos());
 cs.setString(3, getMateria1());
 cs.setString(4, getMateria2());
 cs.setString(5, getMateria3());
 cs.setString(6, getMateria4());
 cs.setString(7, getMateria5());
 cs.setString(8, getMateria6());
 cs.setString(9, getMateria7());
 cs.setString(10, getMateria8());
 cs.setString(11, getMateria9());
 cs.setString(12, getMateria10());
 cs.setString(13, getMateria11());
 cs.setString(14, getMateria12());
 cs.execute();
 JOptionPane.showMessageDialog(null,"Se inserto correctamente");  
 
 } catch (Exception e){
 JOptionPane.showMessageDialog(null,"No se inserto correctamente"+e.toString());
 }
       

}
public void MostrarAlumnos7(JTable paramTablaCalificaciones){
Conexion objetoConexion = new Conexion();
     DefaultTableModel modelo = new DefaultTableModel();
     TableRowSorter<TableModel> OrdenarTabla = new TableRowSorter<TableModel> (modelo);
     paramTablaCalificaciones.setRowSorter(OrdenarTabla);
     String sql= "";
     modelo.addColumn("Id");
     modelo.addColumn("Nombre");
     modelo.addColumn("Apellidos");
     modelo.addColumn("Español");
     modelo.addColumn("Matematicas");
     modelo.addColumn("Civica");
     modelo.addColumn("Ciencias");
     modelo.addColumn("Lengua_Extrangera");
     modelo.addColumn("Deporte");
     modelo.addColumn("Artes");
     modelo.addColumn("Tecnologia");
     modelo.addColumn("Historia");
     modelo.addColumn("Tutoria");
     modelo.addColumn("Vida_Saludablue");
     modelo.addColumn("Equidad_De_Genero");
     
     paramTablaCalificaciones.setModel(modelo);
     
     sql = "SELECT * FROM 3A;";
     String[] datos = new String [15];
     Statement st;
     
     try {
         st = objetoConexion.estableceConexion().createStatement();
         ResultSet rs = st.executeQuery(sql);
         while (rs.next()) {             
             datos[0] = rs.getString(1);
             datos[1] = rs.getString(2);
             datos[2] = rs.getString(3);
             datos[3] = rs.getString(4);
             datos[4] = rs.getString(5);
             datos[5] = rs.getString(6);
             datos[6] = rs.getString(7);
             datos[7] = rs.getString(8);
             datos[8] = rs.getString(9);
             datos[9] = rs.getString(10);
             datos[10] = rs.getString(11);
             datos[11] = rs.getString(12);
             datos[12] = rs.getString(13);
             datos[13] = rs.getString(14);  
             datos[14] = rs.getString(15);  
             
             modelo.addRow(datos);
         }
         paramTablaCalificaciones.setModel(modelo);
         
     } catch (Exception e) {
         JOptionPane.showMessageDialog(null, "No se pudo Mostrar los registos, error: " + e.toString());
     }
     
 }
public void ModificarAlumnos7(JTextField paramCodigo, JTextField paramNombre,JTextField paramApellidos, JTextField paramMateria1, JTextField paramMateria2, JTextField paramMateria3, JTextField paramMateria4, JTextField paramMateria5, JTextField paramMateria6, JTextField paramMateria7, JTextField paramMateria8, JTextField paramMateria9, JTextField paramMateria10, JTextField paramMateria11, JTextField paramMateria12){
setCodigo(Integer.parseInt(paramCodigo.getText()));
setNombre(paramNombre.getText());
setApellidos(paramApellidos.getText());
setMateria1(paramMateria1.getText());
setMateria2(paramMateria2.getText());
setMateria3(paramMateria3.getText());
setMateria4(paramMateria4.getText());
setMateria5(paramMateria5.getText());
setMateria6(paramMateria6.getText());
setMateria7(paramMateria7.getText());
setMateria8(paramMateria8.getText());
setMateria9(paramMateria9.getText());
setMateria10(paramMateria10.getText());
setMateria11(paramMateria11.getText());
setMateria12(paramMateria12.getText());
Conexion objetoConexion = new Conexion();

String consulta = "UPDATE 3A SET 3A.NOMBRE = ?, 3A.APELLIDOS = ?, 3A.ESPAÑOL = ?, 3A.MATEMATICAS = ?, 3A.CIVICA = ?, 3A.CIENCIAS = ?, 3A.LENGUA_EXTRANJERA = ?, 3A.DEPORTE = ?, 3A.ARTES = ?, 3A.TECNOLOGIA = ?, 3A.HISTORIA = ?, 3A.TUTORIA = ?, 3A.VIDA_SALUDABLE = ?, 3A.EQUIDAD_DE_GENERO = ? WHERE 3A.ID = ?;";
    try {
        CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
        cs.setString(1, getNombre());
        cs.setString(2, getApellidos());
        cs.setString(3, getMateria1());
        cs.setString(4, getMateria2());
        cs.setString(5, getMateria3());
        cs.setString(6, getMateria4());
        cs.setString(7, getMateria5());
        cs.setString(8, getMateria6());
        cs.setString(9, getMateria7());
        cs.setString(10, getMateria8());
        cs.setString(11, getMateria9());
        cs.setString(12, getMateria10());
        cs.setString(13, getMateria11());
        cs.setString(14, getMateria12());
        cs.setInt(15, getCodigo());
        cs.execute();
        JOptionPane.showMessageDialog(null, "Modificacion Exitosa");
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al modificar, error: " + e.toString());
    }
}
public void EliminarAlumnos7(JTextField paramCodigo){
    setCodigo(Integer.parseInt(paramCodigo.getText()));
    Conexion objetoConexion = new Conexion();
    String consulta = "DELETE FROM 3A WHERE 3A.ID = ?";
    try{
        CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
        cs.setInt(1, getCodigo());
        cs.execute();
        JOptionPane.showMessageDialog(null, "Se elimino correctamente");
        
    } catch (SQLException e){
        JOptionPane.showMessageDialog(null, "No se pudo eliminar, error: " + e.toString());
    }
}
public void InsertarAlumnos8(JTextField paramNombre,JTextField paramApellidos, JTextField paramMateria1, JTextField paramMateria2, JTextField paramMateria3, JTextField paramMateria4, JTextField paramMateria5, JTextField paramMateria6, JTextField paramMateria7, JTextField paramMateria8, JTextField paramMateria9, JTextField paramMateria10, JTextField paramMateria11, JTextField paramMateria12){
    
        setNombre(paramNombre.getText());
        setApellidos(paramApellidos.getText());
        setMateria1(paramMateria1.getText());
        setMateria2(paramMateria2.getText());
        setMateria3(paramMateria3.getText());
        setMateria4(paramMateria4.getText());
        setMateria5(paramMateria5.getText());
        setMateria6(paramMateria6.getText());
        setMateria7(paramMateria7.getText());
        setMateria8(paramMateria8.getText());
        setMateria9(paramMateria9.getText());
        setMateria10(paramMateria10.getText());
        setMateria11(paramMateria11.getText());
        setMateria12(paramMateria12.getText());    
        Conexion objetoConexion = new Conexion();
        String consulta ="INSERT INTO 3B(NOMBRE, APELLIDOS, ESPAÑOL, MATEMATICAS, CIVICA, CIENCIAS, LENGUA_EXTRANJERA, DEPORTE, ARTES, TECNOLOGIA, HISTORIA, TUTORIA, VIDA_SALUDABLE, EQUIDAD_DE_GENERO) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?); ";
       
        try{
           CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
 cs.setString(1, getNombre());
 cs.setString(2, getApellidos());
 cs.setString(3, getMateria1());
 cs.setString(4, getMateria2());
 cs.setString(5, getMateria3());
 cs.setString(6, getMateria4());
 cs.setString(7, getMateria5());
 cs.setString(8, getMateria6());
 cs.setString(9, getMateria7());
 cs.setString(10, getMateria8());
 cs.setString(11, getMateria9());
 cs.setString(12, getMateria10());
 cs.setString(13, getMateria11());
 cs.setString(14, getMateria12());
 cs.execute();
 JOptionPane.showMessageDialog(null,"Se inserto correctamente");  
 
 } catch (Exception e){
 JOptionPane.showMessageDialog(null,"No se inserto correctamente"+e.toString());
 }
       

}
public void MostrarAlumnos8(JTable paramTablaCalificaciones){
Conexion objetoConexion = new Conexion();
     DefaultTableModel modelo = new DefaultTableModel();
     TableRowSorter<TableModel> OrdenarTabla = new TableRowSorter<TableModel> (modelo);
     paramTablaCalificaciones.setRowSorter(OrdenarTabla);
     String sql= "";
     modelo.addColumn("Id");
     modelo.addColumn("Nombre");
     modelo.addColumn("Apellidos");
     modelo.addColumn("Español");
     modelo.addColumn("Matematicas");
     modelo.addColumn("Civica");
     modelo.addColumn("Ciencias");
     modelo.addColumn("Lengua_Extrangera");
     modelo.addColumn("Deporte");
     modelo.addColumn("Artes");
     modelo.addColumn("Tecnologia");
     modelo.addColumn("Historia");
     modelo.addColumn("Tutoria");
     modelo.addColumn("Vida_Saludablue");
     modelo.addColumn("Equidad_De_Genero");
     
     paramTablaCalificaciones.setModel(modelo);
     
     sql = "SELECT * FROM 3B;";
     String[] datos = new String [15];
     Statement st;
     
     try {
         st = objetoConexion.estableceConexion().createStatement();
         ResultSet rs = st.executeQuery(sql);
         while (rs.next()) {             
             datos[0] = rs.getString(1);
             datos[1] = rs.getString(2);
             datos[2] = rs.getString(3);
             datos[3] = rs.getString(4);
             datos[4] = rs.getString(5);
             datos[5] = rs.getString(6);
             datos[6] = rs.getString(7);
             datos[7] = rs.getString(8);
             datos[8] = rs.getString(9);
             datos[9] = rs.getString(10);
             datos[10] = rs.getString(11);
             datos[11] = rs.getString(12);
             datos[12] = rs.getString(13);
             datos[13] = rs.getString(14);  
             datos[14] = rs.getString(15);  
             
             modelo.addRow(datos);
         }
         paramTablaCalificaciones.setModel(modelo);
         
     } catch (Exception e) {
         JOptionPane.showMessageDialog(null, "No se pudo Mostrar los registos, error: " + e.toString());
     }
     
 }
public void ModificarAlumnos8(JTextField paramCodigo, JTextField paramNombre,JTextField paramApellidos, JTextField paramMateria1, JTextField paramMateria2, JTextField paramMateria3, JTextField paramMateria4, JTextField paramMateria5, JTextField paramMateria6, JTextField paramMateria7, JTextField paramMateria8, JTextField paramMateria9, JTextField paramMateria10, JTextField paramMateria11, JTextField paramMateria12){
setCodigo(Integer.parseInt(paramCodigo.getText()));
setNombre(paramNombre.getText());
setApellidos(paramApellidos.getText());
setMateria1(paramMateria1.getText());
setMateria2(paramMateria2.getText());
setMateria3(paramMateria3.getText());
setMateria4(paramMateria4.getText());
setMateria5(paramMateria5.getText());
setMateria6(paramMateria6.getText());
setMateria7(paramMateria7.getText());
setMateria8(paramMateria8.getText());
setMateria9(paramMateria9.getText());
setMateria10(paramMateria10.getText());
setMateria11(paramMateria11.getText());
setMateria12(paramMateria12.getText());
Conexion objetoConexion = new Conexion();

String consulta = "UPDATE 3B SET 3B.NOMBRE = ?, 3B.APELLIDOS = ?, 3B.ESPAÑOL = ?, 3B.MATEMATICAS = ?, 3B.CIVICA = ?, 3B.CIENCIAS = ?, 3B.LENGUA_EXTRANJERA = ?, 3B.DEPORTE = ?, 3B.ARTES = ?, 3B.TECNOLOGIA = ?, 3B.HISTORIA = ?, 3B.TUTORIA = ?, 3B.VIDA_SALUDABLE = ?, 3B.EQUIDAD_DE_GENERO = ? WHERE 3B.ID = ?;";
    try {
        CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
        cs.setString(1, getNombre());
        cs.setString(2, getApellidos());
        cs.setString(3, getMateria1());
        cs.setString(4, getMateria2());
        cs.setString(5, getMateria3());
        cs.setString(6, getMateria4());
        cs.setString(7, getMateria5());
        cs.setString(8, getMateria6());
        cs.setString(9, getMateria7());
        cs.setString(10, getMateria8());
        cs.setString(11, getMateria9());
        cs.setString(12, getMateria10());
        cs.setString(13, getMateria11());
        cs.setString(14, getMateria12());
        cs.setInt(15, getCodigo());
        cs.execute();
        JOptionPane.showMessageDialog(null, "Modificacion Exitosa");
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al modificar, error: " + e.toString());
    }
}
public void EliminarAlumnos8(JTextField paramCodigo){
    setCodigo(Integer.parseInt(paramCodigo.getText()));
    Conexion objetoConexion = new Conexion();
    String consulta = "DELETE FROM 3B WHERE 3B.ID = ?";
    try{
        CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
        cs.setInt(1, getCodigo());
        cs.execute();
        JOptionPane.showMessageDialog(null, "Se elimino correctamente");
        
    } catch (SQLException e){
        JOptionPane.showMessageDialog(null, "No se pudo eliminar, error: " + e.toString());
    }
}
public void InsertarAlumnos9(JTextField paramNombre,JTextField paramApellidos, JTextField paramMateria1, JTextField paramMateria2, JTextField paramMateria3, JTextField paramMateria4, JTextField paramMateria5, JTextField paramMateria6, JTextField paramMateria7, JTextField paramMateria8, JTextField paramMateria9, JTextField paramMateria10, JTextField paramMateria11, JTextField paramMateria12){
    
        setNombre(paramNombre.getText());
        setApellidos(paramApellidos.getText());
        setMateria1(paramMateria1.getText());
        setMateria2(paramMateria2.getText());
        setMateria3(paramMateria3.getText());
        setMateria4(paramMateria4.getText());
        setMateria5(paramMateria5.getText());
        setMateria6(paramMateria6.getText());
        setMateria7(paramMateria7.getText());
        setMateria8(paramMateria8.getText());
        setMateria9(paramMateria9.getText());
        setMateria10(paramMateria10.getText());
        setMateria11(paramMateria11.getText());
        setMateria12(paramMateria12.getText());    
        Conexion objetoConexion = new Conexion();
        String consulta ="INSERT INTO 3C(NOMBRE, APELLIDOS, ESPAÑOL, MATEMATICAS, CIVICA, CIENCIAS, LENGUA_EXTRANJERA, DEPORTE, ARTES, TECNOLOGIA, HISTORIA, TUTORIA, VIDA_SALUDABLE, EQUIDAD_DE_GENERO) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?); ";
       
        try{
           CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
 cs.setString(1, getNombre());
 cs.setString(2, getApellidos());
 cs.setString(3, getMateria1());
 cs.setString(4, getMateria2());
 cs.setString(5, getMateria3());
 cs.setString(6, getMateria4());
 cs.setString(7, getMateria5());
 cs.setString(8, getMateria6());
 cs.setString(9, getMateria7());
 cs.setString(10, getMateria8());
 cs.setString(11, getMateria9());
 cs.setString(12, getMateria10());
 cs.setString(13, getMateria11());
 cs.setString(14, getMateria12());
 cs.execute();
 JOptionPane.showMessageDialog(null,"Se inserto correctamente");  
 
 } catch (Exception e){
 JOptionPane.showMessageDialog(null,"No se inserto correctamente"+e.toString());
 }
       

}
public void MostrarAlumnos9(JTable paramTablaCalificaciones){
Conexion objetoConexion = new Conexion();
     DefaultTableModel modelo = new DefaultTableModel();
     TableRowSorter<TableModel> OrdenarTabla = new TableRowSorter<TableModel> (modelo);
     paramTablaCalificaciones.setRowSorter(OrdenarTabla);
     String sql= "";
     modelo.addColumn("Id");
     modelo.addColumn("Nombre");
     modelo.addColumn("Apellidos");
     modelo.addColumn("Español");
     modelo.addColumn("Matematicas");
     modelo.addColumn("Civica");
     modelo.addColumn("Ciencias");
     modelo.addColumn("Lengua_Extrangera");
     modelo.addColumn("Deporte");
     modelo.addColumn("Artes");
     modelo.addColumn("Tecnologia");
     modelo.addColumn("Historia");
     modelo.addColumn("Tutoria");
     modelo.addColumn("Vida_Saludablue");
     modelo.addColumn("Equidad_De_Genero");
     
     paramTablaCalificaciones.setModel(modelo);
     
     sql = "SELECT * FROM 3C;";
     String[] datos = new String [15];
     Statement st;
     
     try {
         st = objetoConexion.estableceConexion().createStatement();
         ResultSet rs = st.executeQuery(sql);
         while (rs.next()) {             
             datos[0] = rs.getString(1);
             datos[1] = rs.getString(2);
             datos[2] = rs.getString(3);
             datos[3] = rs.getString(4);
             datos[4] = rs.getString(5);
             datos[5] = rs.getString(6);
             datos[6] = rs.getString(7);
             datos[7] = rs.getString(8);
             datos[8] = rs.getString(9);
             datos[9] = rs.getString(10);
             datos[10] = rs.getString(11);
             datos[11] = rs.getString(12);
             datos[12] = rs.getString(13);
             datos[13] = rs.getString(14);  
             datos[14] = rs.getString(15);  
             
             modelo.addRow(datos);
         }
         paramTablaCalificaciones.setModel(modelo);
         
     } catch (Exception e) {
         JOptionPane.showMessageDialog(null, "No se pudo Mostrar los registos, error: " + e.toString());
     }
     
 }
public void ModificarAlumnos9(JTextField paramCodigo, JTextField paramNombre,JTextField paramApellidos, JTextField paramMateria1, JTextField paramMateria2, JTextField paramMateria3, JTextField paramMateria4, JTextField paramMateria5, JTextField paramMateria6, JTextField paramMateria7, JTextField paramMateria8, JTextField paramMateria9, JTextField paramMateria10, JTextField paramMateria11, JTextField paramMateria12){
setCodigo(Integer.parseInt(paramCodigo.getText()));
setNombre(paramNombre.getText());
setApellidos(paramApellidos.getText());
setMateria1(paramMateria1.getText());
setMateria2(paramMateria2.getText());
setMateria3(paramMateria3.getText());
setMateria4(paramMateria4.getText());
setMateria5(paramMateria5.getText());
setMateria6(paramMateria6.getText());
setMateria7(paramMateria7.getText());
setMateria8(paramMateria8.getText());
setMateria9(paramMateria9.getText());
setMateria10(paramMateria10.getText());
setMateria11(paramMateria11.getText());
setMateria12(paramMateria12.getText());
Conexion objetoConexion = new Conexion();

String consulta = "UPDATE 3C SET 3C.NOMBRE = ?, 3C.APELLIDOS = ?, 3C.ESPAÑOL = ?, 3C.MATEMATICAS = ?, 3C.CIVICA = ?, 3C.CIENCIAS = ?, 3C.LENGUA_EXTRANJERA = ?, 3C.DEPORTE = ?, 3C.ARTES = ?, 3C.TECNOLOGIA = ?, 3C.HISTORIA = ?, 3C.TUTORIA = ?, 3C.VIDA_SALUDABLE = ?, 3C.EQUIDAD_DE_GENERO = ? WHERE 3C.ID = ?;";
    try {
        CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
        cs.setString(1, getNombre());
        cs.setString(2, getApellidos());
        cs.setString(3, getMateria1());
        cs.setString(4, getMateria2());
        cs.setString(5, getMateria3());
        cs.setString(6, getMateria4());
        cs.setString(7, getMateria5());
        cs.setString(8, getMateria6());
        cs.setString(9, getMateria7());
        cs.setString(10, getMateria8());
        cs.setString(11, getMateria9());
        cs.setString(12, getMateria10());
        cs.setString(13, getMateria11());
        cs.setString(14, getMateria12());
        cs.setInt(15, getCodigo());
        cs.execute();
        JOptionPane.showMessageDialog(null, "Modificacion Exitosa");
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al modificar, error: " + e.toString());
    }
}
public void EliminarAlumnos9(JTextField paramCodigo){
    setCodigo(Integer.parseInt(paramCodigo.getText()));
    Conexion objetoConexion = new Conexion();
    String consulta = "DELETE FROM 3C WHERE 3C.ID = ?";
    try{
        CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
        cs.setInt(1, getCodigo());
        cs.execute();
        JOptionPane.showMessageDialog(null, "Se elimino correctamente");
        
    } catch (SQLException e){
        JOptionPane.showMessageDialog(null, "No se pudo eliminar, error: " + e.toString());
    }
}
public void SeleccionarAlumnos(JTable paramTablaAlumnos, JTextField paramId, JTextField paramNombre,JTextField paramApellidos, JTextField paramMateria1, JTextField paramMateria2, JTextField paramMateria3, JTextField paramMateria4, JTextField paramMateria5, JTextField paramMateria6, JTextField paramMateria7, JTextField paramMateria8, JTextField paramMateria9, JTextField paramMateria10, JTextField paramMateria11, JTextField paramMateria12){
    try{
        int fila = paramTablaAlumnos.getSelectedRow();
        if (fila >= 0){
            paramId.setText((paramTablaAlumnos.getValueAt(fila, 0).toString()));
            paramNombre.setText((paramTablaAlumnos.getValueAt(fila, 1).toString()));
            paramApellidos.setText((paramTablaAlumnos.getValueAt(fila, 2).toString()));
            paramMateria1.setText((paramTablaAlumnos.getValueAt(fila, 3).toString()));
            paramMateria2.setText((paramTablaAlumnos.getValueAt(fila, 4).toString()));
            paramMateria3.setText((paramTablaAlumnos.getValueAt(fila, 5).toString()));
            paramMateria4.setText((paramTablaAlumnos.getValueAt(fila, 6).toString()));
            paramMateria6.setText((paramTablaAlumnos.getValueAt(fila, 7).toString()));
            paramMateria7.setText((paramTablaAlumnos.getValueAt(fila, 8).toString()));
            paramMateria8.setText((paramTablaAlumnos.getValueAt(fila, 9).toString()));
            paramMateria9.setText((paramTablaAlumnos.getValueAt(fila, 10).toString()));
            paramMateria10.setText((paramTablaAlumnos.getValueAt(fila, 12).toString()));
            paramMateria11.setText((paramTablaAlumnos.getValueAt(fila, 13).toString()));
            paramMateria12.setText((paramTablaAlumnos.getValueAt(fila, 14).toString()));
            
        } 
        else{
            JOptionPane.showMessageDialog(null, "Fila no seleccionada");
        }
    } catch (Exception e){
        JOptionPane.showMessageDialog(null, "Error de Seleccion, error: " + e.toString());
    }
    
}
   
}
