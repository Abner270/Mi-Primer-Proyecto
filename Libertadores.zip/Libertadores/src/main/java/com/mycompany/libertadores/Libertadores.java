/*paqueteria de manejo cn bd*/
package com.mycompany.libertadores;

public class Libertadores {
    public static void main(String[] args){ 
      Interfaz objetoFormulario = new Interfaz();
      objetoFormulario.setVisible(true);
    }        
}
