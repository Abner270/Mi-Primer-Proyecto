/*trabaja con esa paqueteria*/
package com.mycompany.libertadores;

/*importar libreria de Conexion*/
import java.sql.Connection;
import javax.swing.JOptionPane;
import java.sql.DriverManager;

public class Conexion {
 Connection conectar = null; 
 /*credenciales*/
 String usuario = "root";
 String contraseña = "root";
 /*configuracion de conexion*/
 String bd = "libertadores";
 String ip = "127.0.0.1";
 String port = "3306";
 /*almacenamiento*/
 String cadena = "jdbc:mysql://"+ip+":"+port+"/"+bd;
 
 public Connection estableceConexion(){
 try{
     
     Class.forName("com.mysql.cj.jdbc.Driver");
     conectar=DriverManager.getConnection(cadena, usuario, contraseña);
     //JOptionPane.showMessageDialog(null,"La conexion es exitosa");
     
 } catch (Exception e){
 JOptionPane.showMessageDialog(null, "No se establecio la conexion" + e.toString());   
 }
 return conectar;
 }
 }